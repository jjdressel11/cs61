README.txt
Max Parker and Julia Dressel
Lab 2, Part E
5/13/17

In this Zip file:

README.txt

README describing contents of the zip file.

setup.sql

SQL code that setups up tables in database. Has been previously submitted, but has some minor updates that allow the tables to work in accordance with the front-end interface by the rules of the instructions.


Interface.java

Java code that includes the front-end interface for the database. Some important things to know while using the front-end interface:

-commands into the front-end interface must be typed correctly. if a command is typed incorrectly, the interface will allow you to retype a command until you type one correctly.
-editors must enter in IDs of manuscripts and reviewers that exist within the database. if an ID is entered that is not within the database, nothing in the database will update.
-reviewers must only enter IDs of manuscripts to review assigned to them. if they review a manuscript not assigned to them, the database will not be updated.
-if any user is prompted to enter an ID or another kind of integer, the user must enter an integer. 

Other than those rules, the user interface should be very straightforward by following the prompts.


TO COMPILE AND RUN:

Please have the mysql-connector jar located in the same directory as the Interface.java file.

To compile:

javac -cp ".:./mysql-connector-java-5.1.42-bin.jar" Interface.java

To run:

java -cp ".:./mysql-connector-java-5.1.42-bin.jar" Interface
